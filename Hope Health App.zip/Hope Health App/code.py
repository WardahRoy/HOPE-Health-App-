"""
Hope - Health Tracking Mobile Application
A comprehensive health monitoring app with user authentication and metric tracking
"""

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.core.window import Window
from kivy.uix.popup import Popup
from datetime import datetime
import json
import hashlib
import os

# Set window size for mobile simulation
Window.size = (360, 640)

# Health metric thresholds
HEALTH_THRESHOLDS = {
    'blood_pressure_sys': {'min': 90, 'max': 120, 'unit': 'mmHg', 'label': 'Systolic BP'},
    'blood_pressure_dia': {'min': 60, 'max': 80, 'unit': 'mmHg', 'label': 'Diastolic BP'},
    'blood_sugar': {'min': 70, 'max': 140, 'unit': 'mg/dL', 'label': 'Blood Sugar'},
    'weight': {'min': 50, 'max': 90, 'unit': 'kg', 'label': 'Weight'},
    'bmi': {'min': 18.5, 'max': 24.9, 'unit': '', 'label': 'BMI'},
    'heart_rate': {'min': 60, 'max': 100, 'unit': 'bpm', 'label': 'Heart Rate'},
    'cholesterol': {'min': 125, 'max': 200, 'unit': 'mg/dL', 'label': 'Cholesterol'}
}

class DataManager:
    """Manages user data and health records"""
    
    def __init__(self):
        self.users_file = 'users.json'
        self.health_file = 'health_data.json'
        self.current_user = None
        self.load_data()
    
    def load_data(self):
        """Load user and health data from files"""
        if os.path.exists(self.users_file):
            with open(self.users_file, 'r') as f:
                self.users = json.load(f)
        else:
            self.users = {}
        
        if os.path.exists(self.health_file):
            with open(self.health_file, 'r') as f:
                self.health_data = json.load(f)
        else:
            self.health_data = {}
    
    def save_data(self):
        """Save user and health data to files"""
        with open(self.users_file, 'w') as f:
            json.dump(self.users, f)
        
        with open(self.health_file, 'w') as f:
            json.dump(self.health_data, f)
    
    def hash_password(self, password):
        """Hash password for secure storage"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def register_user(self, username, password):
        """Register a new user"""
        if username in self.users:
            return False, "Username already exists"
        
        self.users[username] = {
            'password': self.hash_password(password),
            'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self.health_data[username] = {}
        self.save_data()
        return True, "Registration successful"
    
    def login_user(self, username, password):
        """Authenticate user login"""
        if username not in self.users:
            return False, "Username not found"
        
        if self.users[username]['password'] == self.hash_password(password):
            self.current_user = username
            return True, "Login successful"
        
        return False, "Incorrect password"
    
    def add_health_record(self, metric, value, notes=''):
        """Add a health record for current user"""
        if self.current_user:
            if metric not in self.health_data[self.current_user]:
                self.health_data[self.current_user][metric] = []
            
            record = {
                'value': value,
                'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'notes': notes
            }
            self.health_data[self.current_user][metric].append(record)
            self.save_data()
            return True
        return False
    
    def get_health_records(self, metric):
        """Get health records for a specific metric"""
        if self.current_user and metric in self.health_data[self.current_user]:
            return self.health_data[self.current_user][metric]
        return []
    
    def get_latest_value(self, metric):
        """Get the latest value for a metric"""
        records = self.get_health_records(metric)
        if records:
            return records[-1]['value']
        return None
    
    def delete_record(self, metric, index):
        """Delete a specific health record"""
        if self.current_user and metric in self.health_data[self.current_user]:
            if 0 <= index < len(self.health_data[self.current_user][metric]):
                self.health_data[self.current_user][metric].pop(index)
                self.save_data()
                return True
        return False

class ColoredButton(Button):
    """Custom button with background color"""
    
    def __init__(self, bg_color=(0.2, 0.6, 0.8, 1), **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ''
        self.background_color = bg_color
        self.color = (1, 1, 1, 1)
        self.size_hint_y = None
        self.height = 50

class LoginScreen(Screen):
    """User login screen"""
    
    def __init__(self, data_manager, **kwargs):
        super().__init__(**kwargs)
        self.data_manager = data_manager
        
        layout = BoxLayout(orientation='vertical', padding=20, spacing=15)
        
        # Add background color
        with layout.canvas.before:
            Color(0.95, 0.97, 1, 1)
            self.rect = Rectangle(size=layout.size, pos=layout.pos)
        layout.bind(size=self._update_rect, pos=self._update_rect)
        
        # Title
        title = Label(text='[b]Hope[/b]\nHealth Tracker', 
                     markup=True,
                     font_size='28sp',
                     size_hint_y=None,
                     height=100,
                     color=(0.2, 0.4, 0.8, 1))
        layout.add_widget(title)
        
        layout.add_widget(Label(size_hint_y=None, height=20))
        
        # Username
        layout.add_widget(Label(text='Username:', 
                               size_hint_y=None, 
                               height=30,
                               color=(0.2, 0.2, 0.2, 1)))
        self.username_input = TextInput(multiline=False, 
                                       size_hint_y=None, 
                                       height=40)
        layout.add_widget(self.username_input)
        
        # Password
        layout.add_widget(Label(text='Password:', 
                               size_hint_y=None, 
                               height=30,
                               color=(0.2, 0.2, 0.2, 1)))
        self.password_input = TextInput(multiline=False, 
                                       password=True,
                                       size_hint_y=None, 
                                       height=40)
        layout.add_widget(self.password_input)
        
        layout.add_widget(Label(size_hint_y=None, height=10))
        
        # Buttons
        login_btn = ColoredButton(text='Login', 
                                 bg_color=(0.2, 0.6, 0.8, 1))
        login_btn.bind(on_press=self.login)
        layout.add_widget(login_btn)
        
        register_btn = ColoredButton(text='Register', 
                                    bg_color=(0.4, 0.7, 0.4, 1))
        register_btn.bind(on_press=self.go_to_register)
        layout.add_widget(register_btn)
        
        layout.add_widget(Label())  # Spacer
        
        self.add_widget(layout)
    
    def _update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size
    
    def login(self, instance):
        username = self.username_input.text.strip()
        password = self.password_input.text
        
        if not username or not password:
            self.show_popup('Error', 'Please enter username and password')
            return
        
        success, message = self.data_manager.login_user(username, password)
        
        if success:
            self.manager.current = 'dashboard'
            self.username_input.text = ''
            self.password_input.text = ''
        else:
            self.show_popup('Login Failed', message)
    
    def go_to_register(self, instance):
        self.manager.current = 'register'
    
    def show_popup(self, title, message):
        popup = Popup(title=title,
                     content=Label(text=message),
                     size_hint=(0.8, 0.3))
        popup.open()

class RegisterScreen(Screen):
    """User registration screen"""
    
    def __init__(self, data_manager, **kwargs):
        super().__init__(**kwargs)
        self.data_manager = data_manager
        
        layout = BoxLayout(orientation='vertical', padding=20, spacing=15)
        
        with layout.canvas.before:
            Color(0.95, 0.97, 1, 1)
            self.rect = Rectangle(size=layout.size, pos=layout.pos)
        layout.bind(size=self._update_rect, pos=self._update_rect)
        
        # Title
        title = Label(text='[b]Create Account[/b]', 
                     markup=True,
                     font_size='24sp',
                     size_hint_y=None,
                     height=80,
                     color=(0.2, 0.4, 0.8, 1))
        layout.add_widget(title)
        
        # Username
        layout.add_widget(Label(text='Username:', 
                               size_hint_y=None, 
                               height=30,
                               color=(0.2, 0.2, 0.2, 1)))
        self.username_input = TextInput(multiline=False, 
                                       size_hint_y=None, 
                                       height=40)
        layout.add_widget(self.username_input)
        
        # Password
        layout.add_widget(Label(text='Password:', 
                               size_hint_y=None, 
                               height=30,
                               color=(0.2, 0.2, 0.2, 1)))
        self.password_input = TextInput(multiline=False, 
                                       password=True,
                                       size_hint_y=None, 
                                       height=40)
        layout.add_widget(self.password_input)
        
        # Confirm Password
        layout.add_widget(Label(text='Confirm Password:', 
                               size_hint_y=None, 
                               height=30,
                               color=(0.2, 0.2, 0.2, 1)))
        self.confirm_input = TextInput(multiline=False, 
                                      password=True,
                                      size_hint_y=None, 
                                      height=40)
        layout.add_widget(self.confirm_input)
        
        layout.add_widget(Label(size_hint_y=None, height=10))
        
        # Buttons
        register_btn = ColoredButton(text='Register', 
                                    bg_color=(0.4, 0.7, 0.4, 1))
        register_btn.bind(on_press=self.register)
        layout.add_widget(register_btn)
        
        back_btn = ColoredButton(text='Back to Login', 
                                bg_color=(0.6, 0.6, 0.6, 1))
        back_btn.bind(on_press=self.go_back)
        layout.add_widget(back_btn)
        
        layout.add_widget(Label())  # Spacer
        
        self.add_widget(layout)
    
    def _update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size
    
    def register(self, instance):
        username = self.username_input.text.strip()
        password = self.password_input.text
        confirm = self.confirm_input.text
        
        if not username or not password:
            self.show_popup('Error', 'Please fill all fields')
            return
        
        if password != confirm:
            self.show_popup('Error', 'Passwords do not match')
            return
        
        if len(password) < 6:
            self.show_popup('Error', 'Password must be at least 6 characters')
            return
        
        success, message = self.data_manager.register_user(username, password)
        
        if success:
            self.show_popup('Success', 'Account created! Please login.')
            self.username_input.text = ''
            self.password_input.text = ''
            self.confirm_input.text = ''
            self.manager.current = 'login'
        else:
            self.show_popup('Registration Failed', message)
    
    def go_back(self, instance):
        self.manager.current = 'login'
    
    def show_popup(self, title, message):
        popup = Popup(title=title,
                     content=Label(text=message),
                     size_hint=(0.8, 0.3))
        popup.open()

class DashboardScreen(Screen):
    """Main dashboard showing all health metrics"""
    
    def __init__(self, data_manager, **kwargs):
        super().__init__(**kwargs)
        self.data_manager = data_manager
        
        self.main_layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        with self.main_layout.canvas.before:
            Color(0.98, 0.98, 1, 1)
            self.rect = Rectangle(size=self.main_layout.size, pos=self.main_layout.pos)
        self.main_layout.bind(size=self._update_rect, pos=self._update_rect)
        
        # Header
        header = BoxLayout(size_hint_y=None, height=60, spacing=10)
        header.add_widget(Label(text='[b]Health Dashboard[/b]',
                              markup=True,
                              font_size='20sp',
                              color=(0.2, 0.4, 0.8, 1)))
        
        logout_btn = Button(text='Logout',
                           size_hint_x=None,
                           width=80,
                           background_color=(0.8, 0.3, 0.3, 1))
        logout_btn.bind(on_press=self.logout)
        header.add_widget(logout_btn)
        
        self.main_layout.add_widget(header)
        
        # Scrollable metrics area
        scroll = ScrollView()
        self.metrics_layout = BoxLayout(orientation='vertical',
                                       spacing=10,
                                       size_hint_y=None,
                                       padding=5)
        self.metrics_layout.bind(minimum_height=self.metrics_layout.setter('height'))
        
        scroll.add_widget(self.metrics_layout)
        self.main_layout.add_widget(scroll)
        
        self.add_widget(self.main_layout)
    
    def _update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size
    
    def on_enter(self):
        """Refresh dashboard when screen is entered"""
        self.refresh_metrics()
    
    def refresh_metrics(self):
        """Update all metric cards"""
        self.metrics_layout.clear_widgets()
        
        # Create metric cards
        metrics = [
            ('blood_pressure_sys', 'Blood Pressure (Sys)'),
            ('blood_pressure_dia', 'Blood Pressure (Dia)'),
            ('blood_sugar', 'Blood Sugar'),
            ('heart_rate', 'Heart Rate'),
            ('weight', 'Weight'),
            ('bmi', 'BMI'),
            ('cholesterol', 'Cholesterol')
        ]
        
        for metric_key, metric_name in metrics:
            card = self.create_metric_card(metric_key, metric_name)
            self.metrics_layout.add_widget(card)
    
    def create_metric_card(self, metric_key, metric_name):
        """Create a card for a health metric"""
        latest_value = self.data_manager.get_latest_value(metric_key)
        
        # Determine status color
        if latest_value is not None:
            threshold = HEALTH_THRESHOLDS[metric_key]
            if latest_value < threshold['min'] or latest_value > threshold['max']:
                status_color = (1, 0.3, 0.3, 1)  # Red
                status_text = 'ALERT'
            else:
                status_color = (0.3, 0.8, 0.3, 1)  # Green
                status_text = 'NORMAL'
        else:
            status_color = (0.7, 0.7, 0.7, 1)  # Gray
            status_text = 'NO DATA'
            latest_value = '-'
        
        # Create container with margin
        container = BoxLayout(orientation='vertical',
                             size_hint_y=None,
                             height=90,
                             padding=[0, 5, 0, 5])
        
        card = BoxLayout(orientation='horizontal',
                        size_hint_y=None,
                        height=80,
                        padding=15,
                        spacing=10)
        
        with card.canvas.before:
            Color(*status_color)
            card.rect = RoundedRectangle(size=card.size,
                                        pos=card.pos,
                                        radius=[10])
        card.bind(size=lambda i, v, r=card.rect: setattr(r, 'size', v),
                 pos=lambda i, v, r=card.rect: setattr(r, 'pos', v))
        
        # Info section
        info = BoxLayout(orientation='vertical', spacing=5)
        
        # Title label
        title_label = Label(text=f'[b]{metric_name}[/b]',
                           markup=True,
                           font_size='16sp',
                           color=(1, 1, 1, 1),
                           halign='left',
                           valign='middle',
                           text_size=(250, None))
        title_label.bind(size=title_label.setter('text_size'))
        info.add_widget(title_label)
        
        # Value and status
        value_text = f'{latest_value}' if latest_value != '-' else 'No data'
        if latest_value != '-':
            value_text += f' {HEALTH_THRESHOLDS[metric_key]["unit"]}'
        
        value_label = Label(text=f'{value_text} - {status_text}',
                           font_size='13sp',
                           color=(1, 1, 1, 1),
                           halign='left',
                           valign='middle',
                           text_size=(250, None))
        value_label.bind(size=value_label.setter('text_size'))
        info.add_widget(value_label)
        
        card.add_widget(info)
        
        # Action button
        btn = Button(text='Manage',
                    size_hint_x=None,
                    width=80,
                    background_color=(0.2, 0.2, 0.2, 0.8),
                    color=(1, 1, 1, 1))
        btn.bind(on_press=lambda x: self.open_metric_screen(metric_key))
        card.add_widget(btn)
        
        container.add_widget(card)
        return container
    
    def open_metric_screen(self, metric):
        """Navigate to specific metric management screen"""
        self.manager.get_screen('metric').set_metric(metric)
        self.manager.current = 'metric'
    
    def logout(self, instance):
        """Logout user"""
        self.data_manager.current_user = None
        self.manager.current = 'login'

class MetricScreen(Screen):
    """Screen for managing individual health metrics"""
    
    def __init__(self, data_manager, **kwargs):
        super().__init__(**kwargs)
        self.data_manager = data_manager
        self.current_metric = None
        
        self.main_layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        with self.main_layout.canvas.before:
            Color(0.98, 0.98, 1, 1)
            self.rect = Rectangle(size=self.main_layout.size, pos=self.main_layout.pos)
        self.main_layout.bind(size=self._update_rect, pos=self._update_rect)
        
        # Header
        header = BoxLayout(size_hint_y=None, height=60, spacing=10)
        
        back_btn = Button(text='← Back',
                         size_hint_x=None,
                         width=80,
                         background_color=(0.6, 0.6, 0.6, 1))
        back_btn.bind(on_press=self.go_back)
        header.add_widget(back_btn)
        
        self.title_label = Label(text='Metric',
                                markup=True,
                                font_size='18sp',
                                color=(0.2, 0.4, 0.8, 1))
        header.add_widget(self.title_label)
        
        self.main_layout.add_widget(header)
        
        # Add new value section
        add_section = BoxLayout(orientation='vertical',
                               size_hint_y=None,
                               height=160,
                               padding=10,
                               spacing=5)
        
        with add_section.canvas.before:
            Color(0.9, 0.95, 1, 1)
            self.add_rect = RoundedRectangle(size=add_section.size,
                                            pos=add_section.pos,
                                            radius=[10])
        add_section.bind(size=lambda i, v: setattr(self.add_rect, 'size', v),
                        pos=lambda i, v: setattr(self.add_rect, 'pos', v))
        
        add_section.add_widget(Label(text='[b]Add New Reading[/b]',
                                    markup=True,
                                    size_hint_y=None,
                                    height=30,
                                    color=(0.2, 0.2, 0.2, 1)))
        
        self.value_input = TextInput(hint_text='Enter value',
                                    multiline=False,
                                    size_hint_y=None,
                                    height=40,
                                    input_filter='float')
        add_section.add_widget(self.value_input)
        
        self.notes_input = TextInput(hint_text='Notes (optional)',
                                    multiline=False,
                                    size_hint_y=None,
                                    height=40)
        add_section.add_widget(self.notes_input)
        
        add_btn = ColoredButton(text='Add Record',
                               bg_color=(0.2, 0.6, 0.8, 1))
        add_btn.bind(on_press=self.add_record)
        add_section.add_widget(add_btn)
        
        self.main_layout.add_widget(add_section)
        
        # History section
        self.main_layout.add_widget(Label(text='[b]History[/b]',
                                         markup=True,
                                         size_hint_y=None,
                                         height=30,
                                         color=(0.2, 0.2, 0.2, 1)))
        
        scroll = ScrollView()
        self.history_layout = BoxLayout(orientation='vertical',
                                       spacing=5,
                                       size_hint_y=None,
                                       padding=5)
        self.history_layout.bind(minimum_height=self.history_layout.setter('height'))
        
        scroll.add_widget(self.history_layout)
        self.main_layout.add_widget(scroll)
        
        self.add_widget(self.main_layout)
    
    def _update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size
    
    def set_metric(self, metric):
        """Set the current metric being managed"""
        self.current_metric = metric
        threshold = HEALTH_THRESHOLDS[metric]
        self.title_label.text = f'[b]{threshold["label"]}[/b]'
        self.value_input.hint_text = f'Enter value ({threshold["unit"]})'
        self.refresh_history()
    
    def refresh_history(self):
        """Refresh the history display"""
        self.history_layout.clear_widgets()
        
        records = self.data_manager.get_health_records(self.current_metric)
        
        if not records:
            self.history_layout.add_widget(
                Label(text='No records yet',
                     size_hint_y=None,
                     height=40,
                     color=(0.5, 0.5, 0.5, 1))
            )
            return
        
        threshold = HEALTH_THRESHOLDS[self.current_metric]
        
        for idx, record in enumerate(reversed(records)):
            value = record['value']
            date = record['date']
            notes = record.get('notes', '')
            
            # Determine status color
            if value < threshold['min'] or value > threshold['max']:
                bg_color = (1, 0.9, 0.9, 1)  # Light red
                text_color = (0.8, 0.2, 0.2, 1)  # Dark red
            else:
                bg_color = (0.9, 1, 0.9, 1)  # Light green
                text_color = (0.2, 0.6, 0.2, 1)  # Dark green
            
            record_card = BoxLayout(orientation='horizontal',
                                   size_hint_y=None,
                                   height=70,
                                   padding=8,
                                   spacing=5)
            
            with record_card.canvas.before:
                Color(*bg_color)
                rect = RoundedRectangle(size=record_card.size,
                                       pos=record_card.pos,
                                       radius=[8])
            record_card.bind(size=lambda i, v, r=rect: setattr(r, 'size', v),
                           pos=lambda i, v, r=rect: setattr(r, 'pos', v))
            
            info = BoxLayout(orientation='vertical')
            info.add_widget(Label(
                text=f'[b]{value} {threshold["unit"]}[/b]',
                markup=True,
                font_size='16sp',
                color=text_color,
                halign='left',
                valign='middle'
            ))
            info.add_widget(Label(
                text=f'{date}',
                font_size='12sp',
                color=(0.3, 0.3, 0.3, 1),
                halign='left',
                valign='middle'
            ))
            if notes:
                info.add_widget(Label(
                    text=f'Note: {notes}',
                    font_size='11sp',
                    color=(0.4, 0.4, 0.4, 1),
                    halign='left',
                    valign='middle'
                ))
            
            record_card.add_widget(info)
            
            # Delete button
            del_btn = Button(text='×',
                           size_hint_x=None,
                           width=40,
                           background_color=(0.8, 0.3, 0.3, 0.8))
            original_idx = len(records) - 1 - idx
            del_btn.bind(on_press=lambda x, i=original_idx: self.delete_record(i))
            record_card.add_widget(del_btn)
            
            self.history_layout.add_widget(record_card)
    
    def add_record(self, instance):
        """Add a new health record"""
        try:
            value = float(self.value_input.text)
            notes = self.notes_input.text.strip()
            
            self.data_manager.add_health_record(self.current_metric, value, notes)
            
            self.value_input.text = ''
            self.notes_input.text = ''
            self.refresh_history()
            
            self.show_popup('Success', 'Record added successfully')
        except ValueError:
            self.show_popup('Error', 'Please enter a valid number')
    
    def delete_record(self, index):
        """Delete a health record"""
        self.data_manager.delete_record(self.current_metric, index)
        self.refresh_history()
    
    def go_back(self, instance):
        """Return to dashboard"""
        self.manager.current = 'dashboard'
    
    def show_popup(self, title, message):
        popup = Popup(title=title,
                     content=Label(text=message),
                     size_hint=(0.8, 0.3))
        popup.open()

class HopeApp(App):
    """Main application class"""
    
    def build(self):
        self.title = 'Hope - Health Tracker'
        
        # Initialize data manager
        self.data_manager = DataManager()
        
        # Create screen manager
        sm = ScreenManager(transition=SlideTransition())
        
        # Add screens
        sm.add_widget(LoginScreen(self.data_manager, name='login'))
        sm.add_widget(RegisterScreen(self.data_manager, name='register'))
        sm.add_widget(DashboardScreen(self.data_manager, name='dashboard'))
        sm.add_widget(MetricScreen(self.data_manager, name='metric'))
        
        return sm

if __name__ == '__main__':
    HopeApp().run()